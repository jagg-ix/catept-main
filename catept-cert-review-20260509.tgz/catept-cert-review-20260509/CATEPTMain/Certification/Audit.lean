import CATEPTMain.Certification.ClassicalMechanics
import CATEPTMain.Certification.RelativityGR
import CATEPTMain.Certification.RelativityGRHodgeDual
import CATEPTMain.Certification.RelativityGRStressConservation
import CATEPTMain.Certification.RelativityGRCurvedMaxwell
import CATEPTMain.Certification.UniversalCertificate

/-!
# Certification — Kernel-Axiom Audit

Standalone reproducible audit for every load-bearing declaration in the
`CATEPTMain/Certification/` namespace.

## Expected output

Every `#print axioms` directive below **must** report exactly:
```
'<decl>' depends on axioms: [propext, Classical.choice, Quot.sound]
```
No `sorryAx` is permitted.

## How to run

```
lake build CATEPTMain.Certification.Audit
```

or open this file in VS Code with the Lean 4 extension active.
-/

-- ── SR sector ─────────────────────────────────────────────────────────────────
#print axioms CATEPTMain.Certification.RelativitySR.canonical_sr
#print axioms CATEPTMain.Certification.RelativitySR.canonical_sr_spinor
#print axioms CATEPTMain.Certification.RelativitySR.sr_properTime_pos

-- ── QM sector ─────────────────────────────────────────────────────────────────
#print axioms CATEPTMain.Certification.Quantum.canonical_quantum
#print axioms CATEPTMain.Certification.Quantum.qm_gr_share_entropic_clock

-- ── Bell / QI sector ──────────────────────────────────────────────────────────
#print axioms CATEPTMain.Certification.Bell.canonical_bell
#print axioms CATEPTMain.Certification.Bell.bell_classical_bound
#print axioms CATEPTMain.Certification.Bell.bell_tsirelson
#print axioms CATEPTMain.Certification.Bell.bell_quantum_violation
#print axioms CATEPTMain.Certification.Bell.singlet_is_entangled
#print axioms CATEPTMain.Certification.Bell.canonical_bell_entropic

-- ── Path-integral sector ──────────────────────────────────────────────────────
#print axioms CATEPTMain.Certification.PathIntegral.canonical_pi_exists
#print axioms CATEPTMain.Certification.PathIntegral.gr_qm_shared_damping
#print axioms CATEPTMain.Certification.PathIntegral.wick_is_consistent

-- ── Modular-thermal sector ────────────────────────────────────────────────────
#print axioms CATEPTMain.Certification.ModularThermal.canonical_thermal_bundle
#print axioms CATEPTMain.Certification.ModularThermal.thermal_imaginary_action_eq
#print axioms CATEPTMain.Certification.ModularThermal.thermal_tauEnt_neg_log_Z
#print axioms CATEPTMain.Certification.ModularThermal.canonical_qm_matsubara_eq

-- ── Classical mechanics — Herglotz/contact damped oscillator certificate ──────
#print axioms CATEPTMain.Certification.ClassicalMechanics.canonical_classical
#print axioms CATEPTMain.Certification.ClassicalMechanics.classical_slot_consistent
#print axioms CATEPTMain.Certification.ClassicalMechanics.classical_clock_eq_tauEnt
#print axioms CATEPTMain.Certification.ClassicalMechanics.classical_dissipation_nonpos
#print axioms CATEPTMain.Certification.ClassicalMechanics.classical_decayRate_eq
#print axioms CATEPTMain.Certification.ClassicalMechanics.classical_zero_entropy_reduces

-- ── GR flat (Minkowski) certificate ──────────────────────────────────────────
#print axioms CATEPTMain.Certification.RelativityGR.canonical_gr_flat
#print axioms CATEPTMain.Certification.RelativityGR.gr_flat_slot_consistent
#print axioms CATEPTMain.Certification.RelativityGR.gr_flat_tolman_trivial

-- ── GR tensor certificate (CERT-UP-005 Stage A) ───────────────────────────────
#print axioms CATEPTMain.Certification.RelativityGR.canonical_gr_tensor
#print axioms CATEPTMain.Certification.RelativityGR.gr_tensor_faraday_defined
#print axioms CATEPTMain.Certification.RelativityGR.gr_tensor_stress_energy_defined

-- ── Universal certificate (CERT-UP-007 — 9-sector upgrade) ───────────────────
#print axioms CATEPTMain.Certification.universalConsistencyCertificate
#print axioms CATEPTMain.Certification.universal_sr_properTime_pos
#print axioms CATEPTMain.Certification.universal_qm_gr_shared_clock
#print axioms CATEPTMain.Certification.canonicalCommonClock
-- ── GR Einstein certificate (CERT-UP-005 Stage B — structural, kernel-only) ───
#print axioms CATEPTMain.Certification.RelativityGR.canonical_gr_einstein

-- ── GR Hodge dual involution (kernel-transparent bivector layer) ─────────────
#print axioms CATEPTMain.Certification.RelativityGR.gravitasFaraday_hodgeStar_involutive

-- ── GR stress conservation (kernel-transparent constant model) ───────────────
#print axioms CATEPTMain.Certification.RelativityGR.canonical_radiation_stress_conserved

-- ── GR curved-Maxwell bridge certificate (reused NSCATEPT core surface) ─────
#print axioms CATEPTMain.Certification.RelativityGR.canonical_gr_curved_maxwell
#print axioms CATEPTMain.Certification.RelativityGR.gr_curved_maxwell_flat_wave_eq
